CREATE VIEW view_2 AS
  (SELECT
     count(`booklibrarydb`.`loan`.`lib_id1`) AS `COUNT(lib_id1)`,
     `booklibrarydb`.`book`.`title`          AS `title`
   FROM ((`booklibrarydb`.`book`
     JOIN `booklibrarydb`.`library`) JOIN `booklibrarydb`.`loan`
       ON (((`booklibrarydb`.`library`.`isbn` = `booklibrarydb`.`book`.`isbn`) AND
            (`booklibrarydb`.`loan`.`lib_id2` = `booklibrarydb`.`library`.`lib_id`))))
   WHERE (year(`booklibrarydb`.`loan`.`loan_date`) = year(curdate()))
   GROUP BY `booklibrarydb`.`book`.`isbn`
   ORDER BY count(`booklibrarydb`.`loan`.`lib_id1`) DESC);
